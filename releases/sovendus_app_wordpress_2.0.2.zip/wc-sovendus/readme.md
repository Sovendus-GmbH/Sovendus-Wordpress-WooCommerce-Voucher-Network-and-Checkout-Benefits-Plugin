=== Sovendus App ===
Contributors: sovendus
Tags: Sovendus, Checkout Marketing
Requires at least: 4.7
Tested up to: 6.7.1
Stable tag: 2.0.2
Requires PHP: 7.0
License: GPLv3
License URI: <https://www.gnu.org/licenses/gpl-3.0.html>
The official Sovendus App allows you to easily integrate Sovendus Voucher Network, Checkout Benefits, Checkout Products and Optimize.

## External Services
